// Adam Jean
// CST283


import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class jeopardy {
    public static final String filename = "src/jeopardydata.txt";
    static int max = 210000;
    static final String delimiter = "[|]";

    public static String[] bigLine = new String[max];
    public static String[] showDate = new String[max];
    public static String[] round = new String[max];
    public static String[] category = new String[max];
    public static String[] value = new String[max];
    public static String[] question = new String[max];
    public static String[] answer = new String[max];
    public static String[] day = new String[max];
    public static String[] month = new String[max];
    public static String[] year = new String[max];

    static String searchType;
    static String searchBound;
    static String searchMonth;
    static String searchDay;
    static String searchYear;

    public static void main(String[] args) {
        int x = 0;
        writeMainArray();
        splitRow();
        splitDate();
        while (true) {
            x = searchBreakdown();
            if (x == -1)
                return;
            doSearch();
        }
    }

    // This method reads the .txt and inputs it into a big array
    public static void writeMainArray() {
        try {
            File file = new File(filename);
            Scanner scanner = new Scanner(file);
            int i = 0;
            while (scanner.hasNextLine() && i < max) {
                bigLine[i] = scanner.nextLine();
                i++;
            }
            scanner.close();
            max = i;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    // This method uses a split and a loop break up the main method into columns
    public static void splitRow() {
        for (int i = 0; i < max; i++) {
            if (bigLine[i] != null) {
                String[] columns = bigLine[i].split(delimiter);
                showDate[i] = columns[0];
                round[i] = columns[1];
                category[i] = columns[2];
                value[i] = columns[3];
                question[i] = columns[4];
                answer[i] = columns[5];
            }
            else
                break;
        }
    }

    // This method takes the showDate array and splits it into a month, day and year
    // array
    public static void splitDate() {
        for (int i = 0; i < max; i++) {
            if (showDate[i] != null) {
                String[] dateSplitter = showDate[i].split("[/]");
                month[i] = dateSplitter[0];
                day[i] = dateSplitter[1];
                year[i] = dateSplitter[2];
            }
        }
    }

    // This method takes user input and searches the subcategories
    public static int searchBreakdown() {
        System.out.println("Welcome to the menu. Please enter a query");
        Scanner scan = new Scanner(System.in);
        String search = scan.nextLine();
        if (search.equals("END"))
            return -1;
        String[] searchSplitter = search.split(",");
        searchType = searchSplitter[0];
        searchBound = searchSplitter[1];
        if (searchBound != null) {
            String[] searchDateSplitter = searchBound.split("[/]");
            if (searchDateSplitter.length == 3) {
                searchMonth = searchDateSplitter[0];
                searchDay = searchDateSplitter[1];
                searchYear = searchDateSplitter[2];
            }
           else if (searchDateSplitter.length == 2) {
                searchMonth = searchDateSplitter[0];
                searchYear = searchDateSplitter[1];
            }
            else if (searchDateSplitter.length == 1) {
                searchYear = searchDateSplitter[0];
            }
        }
        return 0;
    }

    // This method uses for loops to check each search type. The loops use .equals
    // to check the search bounds. When true, the loop
    // will print out the desired results
    public static void doSearch() {
        if (searchType.equals("QD"))
            for (int i = 0; i < max; i++) {
                if (month[i] == null || day[i] == null || year[i] == null)
                    return;
                if (month[i].equals(searchMonth) && day[i].equals(searchDay) && year[i].equals(searchYear)) {
                    System.out.println(question[i] + " " + answer[i]);
                }
            }


        else if (searchType.equals("MC")) {
            for (int i = 0; i < max; i++) {
                if (month[i].equals(searchMonth) && year[i].equals(searchYear)) {
                    System.out.println(category[i]);
                }
            }
        }

        else if (searchType.equals("FJ")) {
            for (int i = 0; i < max; i++) {
                if (year[i].equals(searchYear) && round[i].equals("Final Jeopardy!")) {
                    System.out.println(question[i] + " " + answer[i]);
                }
            }
        }
        else if (searchType.equals("TW")) {
            for (int i = 0; i < max; i++) {
                if (question[i].contains(searchBound) || answer[i].contains(searchBound)) {
                    System.out.println(question[i] + " " + answer[i]);
                }
            }
        }
        else if (searchType.equals("AJ")) {
            for (int i = 0; i < max; i++) {
                if (month[i].equals(searchMonth) && day[i].equals(searchDay) && year[i].equals(searchYear)) {
                    System.out.println(value[i]);
                }
            }
        }
        else {
            System.out.println("Please enter a valid search");
        }
        System.out.println("Type END to terminate program");

    }
    }
