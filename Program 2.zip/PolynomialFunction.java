/**
 * Adam Jean
 * CST -283
 * This class takes in @param int degree and @param double[] coefficient array
 * and builds a polynomial
 */

public class PolynomialFunction {
    private int degree;
    private double[] coefficientArray;


    //Main method for testing
    public static void main(String[] args){

    }

    /**
     * Default constructor for PolynomialFunction.
     * Initializes the degree to 2 and sets default coefficients.
     */
    public PolynomialFunction() {
        degree = 2;
        coefficientArray = new double[3];
        coefficientArray[0] = 1;
        coefficientArray[1] = 1;
        coefficientArray[2] = 1;
    }

    /**
     * Parameterized constructor.
     * Takes a string of coefficients and sets them for the polynomial.
     *
     * @param coeff string of coefficients
     */
    public PolynomialFunction(String coeff) {
        setFunctionCoeff(coeff);
    }

    /**
     * Builds a table of values for the polynomial function.
     *
     * @param startX    Starting x-value for the table
     * @param endX       Ending x-value for the table.
     * @param increment Increment for x in the table.
     * @return A string representing the table of values.
     */
    public String buildTable(double startX, double endX, double increment) {
        StringBuilder table = new StringBuilder("x y\n");
        for (double x = startX; x <= endX; x += increment) {
            double y = getY(x);
            table.append(String.format("%.0f %.0f%n",x,y));
        }
        return table.toString();
    }

    /**
     * Calculates y for a given x.
     *
     * @param x The x-value to calculate y
     * @return The y-value
     */
    public double getY(double x){
        double y = 0;
        for (int i = 0; i<= degree; i++){
            y += coefficientArray[i] * Math.pow(x, degree - 1 - i);
        }
        return y;
    }

    /**
     * Gets the degree of the polynomial function.
     *
     * @return The degree of the polynomial
     */
    public int getDegree(){
        degree = coefficientArray.length;
        return degree;
    }


    /**
     * Sets the coefficients of the polynomial function.
     *
     * @param coeff string of coefficients.
     */
        public void setFunctionCoeff(String coeff) {
        String[] coeffStrings = coeff.split(",");
        degree = coeffStrings.length - 1;
        coefficientArray = new double[degree + 1];
        for (int i = 0; i <= degree; i++) {
            coefficientArray[i] = Double.parseDouble(coeffStrings[i]);
        }
    }

    /**
     * Generates a toString of the polynomial function.
     *
     * @return A string representing the polynomial function in y= form
     */
        public String toString() {
        StringBuilder functionString = new StringBuilder("y = ");
        for (int i = 0; i <= degree; i++) {
            if (i != 0) {
                functionString.append(" + ");
            }
            functionString.append(coefficientArray[i]);
            if (degree - i > 0) {
                functionString.append("x^").append(degree - i);
            }
        }
        return functionString.toString();
    }
}
