import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class PolynomialFunctionDemo extends Application {
    PolynomialFunction polynomialFunction;
    TextField coefficientsField;
    TextField tableValsArea;
    TextField xValueField;
    TextArea tableTextArea;
    Label resultLabel;
    Label resultLabel2;


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        polynomialFunction = new PolynomialFunction();

        primaryStage.setTitle("Polynomial Function Demo");

        // Create UI elements
        Label coefficientsLabel = new Label("Coefficients:");
        coefficientsField = new TextField("");

        Label tableVals = new Label("Table Inputs");
        tableValsArea = new TextField("");

        Label xValueLabel = new Label("X Value:");
        xValueField = new TextField("");

        Button calculateButton = new Button("Calculate Y");
        calculateButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                calculateY();
            }
        });

        resultLabel = new Label("");
        resultLabel2 = new Label("");


        Label tableLabel = new Label("Table of Values:");
        tableTextArea = new TextArea();


        Button generateTableButton = new Button("Generate Table");
        generateTableButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                generateTable();
            }
        });

        // Create layouts
        VBox mainLayout = new VBox(10) ;
        mainLayout.setPadding(new Insets(10));
        mainLayout.getChildren().addAll(
                coefficientsLabel, coefficientsField,
                xValueLabel, xValueField,
                calculateButton, resultLabel, resultLabel2,
                tableLabel, tableTextArea,
                tableVals, tableValsArea,
                generateTableButton

        );


        // Create the scene and set it in the stage
        Scene scene = new Scene(mainLayout, 400, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void calculateY() {
        String coefficientsText = coefficientsField.getText();
        String xValueText = xValueField.getText();

        try {
            polynomialFunction.setFunctionCoeff(coefficientsText);
            double x = Double.parseDouble(xValueText);
            double y = polynomialFunction.getY(x);
            resultLabel.setText("y = " + y);
            resultLabel2.setText(polynomialFunction.toString());

        } catch (NumberFormatException e) {
            resultLabel.setText("Invalid input. Please check your coefficients and x value.");
        }
    }


    private void generateTable() {
        String coefficientsText = tableValsArea.getText();
        String[] searchSplitter = coefficientsText.split(",");
        String startXText = searchSplitter[0];
        String endXText = searchSplitter[1];
        String incrementText = searchSplitter[2];


        try {
            double startX = Double.parseDouble(startXText);
            double endX = Double.parseDouble(endXText);
            double increment = Double.parseDouble(incrementText);

            String table = polynomialFunction.buildTable(startX, endX, increment);
            tableTextArea.setText(table);

        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            tableTextArea.setText("Invalid input. Please check your coefficients and x value.");
        }

    }
}
